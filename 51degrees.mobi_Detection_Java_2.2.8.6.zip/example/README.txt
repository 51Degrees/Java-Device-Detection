

  Servlet.java is an example of a Servlet that runs 51Degrees.mobi. 

  If you are un-familier with Servlets and would like a fully documented tutorial of
  using one with NetBeans IDE <http://www.netbeans.org>, please visit the link below:
  <http://51degrees.mobi/Support/Documentation/Java.aspx#JavaWebApp?CATReferrer=1758> 


  CommandLineTest.jar uses the 51Degrees.mobi.detection.core.jar file to demonstrate
  a simple impementation of the 51Degrees.mobi Java solution. You can run the file 
  through the command line or by using the batch file "run.bat". By default the embedded
  Lite data file will be used, specify an alternative as a command line argument or by
  placing the file in the "example" directory and using "run.bat".