package fiftyone.mobile.detection.trie;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * Due to the size of the Trie tree structure, the data cannot fit into a single
 * ByteBuffer. Therefore, this class is used to wrap the file channel and and
 * become logically one channel.
 *
 * @author 51Degrees.mobi
 * @version 1.0
 */
public class FiftyOneMapper {

    /**
     * Creates a logger for this class
     */
    private static final Logger _logger = LoggerFactory.getLogger(FiftyOneMapper.class);
    
    /**
     * Buffers mapped to the files channel.
     */
    private ArrayList<MappedByteBuffer> _buffers;
    /**
     * The File Channel linked to the trie data.
     */
    private final FileChannel _triFile;
    /**
     * The start position of the tree in the trie file.
     */
    private final long _start;
    /**
     * Logical position of the data needed in the file.
     */
    private long _position;
    /**
     * Actual position of Data needed. e.g. The index of one of the Byte
     * Buffers.
     */
    private long _actualPosition;

    /**
     *
     * Creates the class by creating multiple ByteBuffers that can be read from.
     *
     * @param reader File channel to read from.
     */
    public FiftyOneMapper(FileChannel reader) {
        long treeStart = 0;
        _triFile = reader;
        // Allocate the exact amount of buffers to ArrayList
        _buffers = new ArrayList<MappedByteBuffer>(3);
        try {
            treeStart = reader.position();

            // Read from the amount read so far to max size of an array.
            _buffers.add(reader.map(MapMode.READ_ONLY, treeStart, Integer.MAX_VALUE));
            // then read the rest of the data into another buffer.
            _buffers.add(reader.map(MapMode.READ_ONLY, (treeStart + Integer.MAX_VALUE), (reader.size() - (treeStart + Integer.MAX_VALUE))));

            // Set the Order to little endian.
            _buffers.get(0).order(ByteOrder.LITTLE_ENDIAN);
            _buffers.get(1).order(ByteOrder.LITTLE_ENDIAN);

        } catch (IOException ex) {
            
            _logger.error("Exception Creating FiftyoneMapper", ex);
        }

        _start = treeStart;
        _position = 0;
        _actualPosition = 0;
    }

    /**
     *
     * Determines the ByteBuffer index that the data is located in.
     *
     * @param position Position to locate.
     * @return Position calculated.
     */
    private long getLocation(long position) {
        if (position > (long) Integer.MAX_VALUE) {
            return position -= (long) Integer.MAX_VALUE;
        }
        return position;
    }

    /**
     *
     * Returns the current logical position value.
     *
     * @return the current logical position in the file.
     */
    public long getPosition() {
        return _position + _start;
    }

    /**
     *
     * Sets the logical position in the file.
     *
     * @param position position value.
     */
    public void setPosition(long position) {
        _position = position - _start;
        // Calculate the logical poition form the actual.
        _actualPosition = getLocation(_position);
    }

    /**
     *
     * Sets the logical position in the Buffers.
     *
     * @param position position value.
     */
    private void setInternalPosition(long position) {
        _position = position;
        _actualPosition = getLocation(_position);
    }

    /**
     *
     * Read an Unsigned byte from the file at the current location.
     *
     * @return The value read.
     */
    public short readByte() {
        short s = 0;

        byte[] value = getValue(DataType.Byte);
        s |= (value[0] & 0xFF);

        setInternalPosition(_position + 1);

        return s;
    }

    /**
     *
     * Read an Unsigned byte from the file at a specified location.
     *
     * @param position Position to read from.
     * @return The value read.
     */
    public short readByte(long position) {
        setPosition(position);
        return readByte();
    }

    /**
     * Read an Unsigned short from the file at the current location.
     *
     * @return The value read.
     */
    public int readShort() {
        int i = 0;

        byte[] value = getValue(DataType.Unsigned_Short);
        i |= (value[1] & 0xFF);
        i <<= 8;
        i |= (value[0] & 0xFF);
        setInternalPosition(_position + 2);

        return i;
    }

    /**
     *
     * Read an Unsigned short from the file at a specified location.
     *
     * @param position Position to read from.
     * @return The value read.
     */
    public int readShort(long position) {
        setPosition(position);
        return readShort();
    }

    /**
     *
     * Read an Unsigned integer from the file at the current location.
     *
     * @return The Value read.
     */
    public long readInt() {
        long l = 0;

        byte[] value = getValue(DataType.Unsigned_Int);
        l |= (value[3] & 0xFF);
        l <<= 8;
        l |= (value[2] & 0xFF);
        l <<= 8;
        l |= (value[1] & 0xFF);
        l <<= 8;
        l |= (value[0] & 0xFF);

        setInternalPosition(_position + 4);

        return l;
    }

    /**
     *
     * Read an Unsigned integer from the file at a specified location.
     *
     * @param position Position to read from.
     * @return The value read.
     */
    public long readInt(long position) {
        setPosition(position);
        return readInt();
    }

    /**
     *
     * Reads a certain data type from the file e.g. byte, Unsigned
     * Integer etc.
     *
     * @param dataType Type of data to read.
     * @return byte array of data.
     */
    private byte[] getValue(DataType dataType) {
        // Array to hold data that is read.
        byte[] value;

        // Amount of data to read.
        int readSize;

        // Determine size of read
        switch (dataType) {
            case Byte:
                value = new byte[1];
                readSize = 1;
                break;
            case Unsigned_Short:
                value = new byte[2];
                readSize = 2;
                break;
            case Unsigned_Int:
                value = new byte[4];
                readSize = 4;
                break;
            default:
                return null;
        }

        long overlap = _actualPosition + (long) readSize;

        // Determine if read overlaps into both buffers
        if (overlap > (long) Integer.MAX_VALUE) {
            // Read will be in both buffers

            // Determine amount to read from each buffer buffer.
            long buf2read = overlap - (long) Integer.MAX_VALUE;
            int buf1read = readSize - (int) overlap;

            // Set first buffer position
            _buffers.get(0).position((int) _actualPosition);

            // Read from First buffer
            for (int i = 0; i < (int) buf1read; i++) {
                value[i] = _buffers.get(0).get();
            }

            // Set second buffer positon
            _buffers.get(1).position(0);

            // Read from second buffer
            for (int i = (int) buf1read; i < buf2read; i++) {
                value[i] = _buffers.get(1).get();
            }
        } else {
            // Read occurs in one buffer
            ByteBuffer temp;
            /*
             * If actualPosition and Position are equal then its the first
             * buffer else it's the second buffer
             */
            if (_actualPosition == _position) {
                temp = _buffers.get(0);
            } else {
                temp = _buffers.get(1);
            }

            // Set Position to read from.
            temp.position((int) _actualPosition);

            // Read from the buffer. 
            for (int i = 0; i < readSize; i++) {
                value[i] = temp.get();
            }
        }
        return value;
    }

    /**
     * Clears the ByteBuffers and closes the File Channel.
     */
    public void close() {
        for (ByteBuffer b : _buffers) {
            b.clear();
            b = null;
        }
        try {
            _triFile.close();
        } catch (IOException ex) {
            _logger.error("Failed to close Tri data file FileChannel: ", ex);
        }
    }

    /**
     * Defines what data type is being read from a given buffer.
     */
    private static enum DataType {

        Byte, Unsigned_Short, Unsigned_Int;
    }
}
